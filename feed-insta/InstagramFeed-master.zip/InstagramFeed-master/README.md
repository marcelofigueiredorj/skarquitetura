# ⚠️ This repository has been archived ⚠️

The focus of this repository was to provide an easy and ready to use plugin to display an Instagram Feed but since latest Instagram changes, this no longer makes sense. Please, move to an official API based plugin.

If you feel this repo should not be archived, please reach out and let us know. Archiving can always be reversed if needed.

# InstagramFeed [![Build Status](https://travis-ci.com/jsanahuja/InstagramFeed.svg?branch=master)](https://travis-ci.com/jsanahuja/InstagramFeed)
Instagram Feed without using the instagram API. Neither jQuery!

This is a vanilla JavaScript version of the original [jquery.instagramFeed](https://github.com/jsanahuja/jquery.instagramFeed)

## Documentation

[Full documentation and examples here](https://www.sowecms.com/demos/InstagramFeed)

## Contributing

Read and follow the [CONTRIBUTING.md](./CONTRIBUTING.md) before sending any pull request.
